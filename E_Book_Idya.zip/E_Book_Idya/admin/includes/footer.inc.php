<div id="footer-wrap">
	<p id="legal">(c) 2017 OurSite. Design by <a href="http://www.GBKSTUDIOS.com"> GBK STUDIOS </a>.</p>
	</div>