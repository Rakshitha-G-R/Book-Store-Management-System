<?php session_start();

		$_SESSION=array();		//session_destroy();
		
		echo "Logged Out";				
		header("location:index.php");
		
	
					
?>

	
	
	
